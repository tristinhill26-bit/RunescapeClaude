# Changelog

## 0.5.0 + Quick Stack patch (4)

- Fixed: drawers placed against each other could land a quarter metre in front of or behind their neighbour,
  so a wall of drawers looked skewed. They now snap only by their back corners and always end up flush.
  Drawers already placed keep their position: remove and re-place the ones that stick out.

## 0.5.0 + Quick Stack patch (3)

- Fixed: quick stack and the Stack button failed with "BadImageFormatException: Bad IL format" in the log, and
  nothing went into the drawers. A config value was read with a call the game's runtime rejects.

## 0.5.0 + Quick Stack patch (2)

- Quick stack fills the drawers in every case: with a chest open (quick stack to that chest) and in multiplayer,
  where Quick Stack leaves the nearby chests alone by default. The first patch followed those chest rules and did
  nothing in those cases.
- Store all (with a chest open) first puts into the drawers what they already hold; the rest goes into the chest.
- The drawers use their own range: Range in "8 - Quick Stack", 20 m by default. New key StoreAll.
- Every quick stack and Store all writes a line to the BepInEx log: drawers in range, items put away.
- The version stays 0.5.0, so players with the unpatched 0.5.0 see no version warning.

## 0.5.0

- Costs at the crafting stations and in the build menu show what you have next to what you need:
  **2/3+10** = 2 needed, 3 in your inventory, 10 in the drawers nearby. ShowStock in the Crafting section of the
  config switches to the total (2/13) or back to the vanilla number (Off); it is a personal setting, never taken
  from the server. Numbers too long for the box shrink to fit.
- Nothing changes in the drawers, the ledger or the saved worlds. Players and the server should still update
  together, or the chat shows the version warning.

## 0.4.1

- No more "The LiberationSans SDF Font Asset was not found. There is no Font Asset assigned to count." warnings
  in the log and in the console: the drawer fronts now get their font before the text is created. Nothing else
  changes in how the drawers look or work.
- Players and the server should all update together: a different version shows a warning in the chat.

## 0.4.0

- Previous release.
