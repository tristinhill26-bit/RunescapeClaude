# ItemDrawers-Ymiron

Drawers for the bulk of your materials, with things the other drawer mods do not have:

- **The Drawer Ledger**: a lectern with the book of everything stored in the drawers around it. Open it to see
  all your stock in one searchable grid, take what you need from there, and put your loot away from one place.
- **Crafting and building from the drawers**: workbenches, forges, cauldrons and the hammer use the materials in
  the drawers near you, after the ones in your inventory. No other mod needed.
- **Epic Loot materials** go in the drawers too, and come out as they went in.

## Drawers

Built with the hammer, in their own **Drawers** tab (with Jotunn installed, as most modded games have; otherwise
in the Furniture tab, after the chests). Each one is 0.5 x 0.5 m (DrawerSize in the config), half as deep, and
snaps to its neighbours: four side by side fill a 2 m wall.

| Tier | Station | Holds | Cost |
|---|---|---|---|
| Wooden Drawer | Workbench | 24 stacks | Wood 10 |
| Iron-bound Drawer | Forge | 64 stacks | Fine wood 10, Iron 2 |
| Black Marble Drawer | Black forge | 160 stacks | Black marble 10, Yggdrasil wood 6, Copper 2 |

A wooden drawer holds 24 x 50 = 1200 stone.

The front shows the item's icon, how many there are and a bar of how full it is.

- **Use a hotbar item (1-8) on a drawer**: it is now set to that item, and every one of it in your inventory goes in.
- **E**: take a stack. **Ctrl + E**: take one.
- **Shift + E**: put away every item of that kind from your inventory.
- A drawer **keeps its item when it runs out**: it shows it at 0 and keeps collecting it.
  **Ctrl + E on an empty drawer** frees it for another item.

**Pickup**: items lying on the ground within 5 m of a drawer go into the drawers already set to them. Empty
your bag on the storeroom floor and everything files itself away. A drawer never takes an item it was not set to.

Drawers take every stackable item (materials, food, potions, ammo...), also from other mods: **Epic Loot**
dusts, essences, reagents, runestones and shards keep their data. Never weapons, armor or tools. When a drawer
is broken or taken down, everything inside comes out packed in cargo crates.

## The Drawer Ledger

Built at the workbench (Wood 10, Leather scraps 4, Resin 4). Use it to open your inventory with the ledger's page
in place of a chest's: every item in the drawers within 40 m, sorted by name, with a search box.

- **Click** an item: take a stack. **Shift + click**: take as many as you can carry. **Right click**: take one.
- **Ctrl + click** an item of your inventory: into the drawers that already hold it, or a free compartment.
- **Store all**: every item of your inventory that some drawer already holds goes there (the hotbar row stays).

## Crafting from the drawers

Recipe and building costs count the drawers within 25 m of you; when you craft or build, what your inventory
lacks is taken from them. Every cost, at the stations and in the build menu, shows what you need and what you
have: **2/3+10** = 2 needed, 3 in your inventory, 10 in the drawers (ShowStock in the config: Split, Total for
2/13, or Off). Drawers inside a ward you cannot open are left alone, by crafting and by the ledger.

## Config

`BepInEx/config/ymiron.valheim.itemdrawers.cfg`, reloaded while the game runs:

- General: the size of the drawers, the name of the hammer tab, the key for "take one", items that can never be stored.
- Crafting: on/off, range, how costs show your stock (personal setting).
- Ledger: range, whether Store all skips the hotbar, cost and station.
- One section per tier: on/off, stacks per drawer, cost, station.
- Drawer Front: distance from the wood, size and position of the icon, the label, the number and the bar, brightness.
  Applied at once to every drawer (with Configuration Manager, right from the F1 menu).
- Pickup: on/off, range, how often.

## Multiplayer and dedicated servers

- Install the mod **on the server too**: its config is then everybody's config (capacity, costs, size, ranges,
  pickup, crafting from drawers). Each player keeps their own personal settings: the look of the fronts, the keys,
  the name of the hammer tab. Without the mod on the server, everybody uses their own file.
- Every change to a drawer is a request sent to the game that runs it on the network, which applies them one after
  the other: two players using the same drawer at once, or dumping their bags next to it together, never lose or
  duplicate items. What does not fit comes back.
- A player without the mod cannot see the drawers; the others get a message in the chat. A drawer they happen to
  run on the network is taken over by whoever uses it.

## Install

With r2modman / Thunderstore Mod Manager: Settings > Import local mod > pick the zip. By hand: copy
`ItemDrawers.dll` into `BepInEx/plugins`.
